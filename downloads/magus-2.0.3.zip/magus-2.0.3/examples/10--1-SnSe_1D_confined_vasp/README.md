Example 9.1  
GAsearch of 1D SnSe in nanotube by confined VASP
====================================================  
Please note that this example requires modified VASP code for confined systems to work properly. For more information, please refer to [Chi Ding et al, 2022, Chinese Phys. Lett. 39 036101] and contact Dr. Ding for details.

See 'SnSe.vasp' for the referance structure.
