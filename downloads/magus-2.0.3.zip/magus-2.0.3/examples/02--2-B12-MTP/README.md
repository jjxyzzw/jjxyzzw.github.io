You must have mlip to run this example:  
https://mlip.skoltech.ru/download/  
  
Relax 2000 structures with MTP and VASP.  
gen.traj: random generated 2000 strucutures of boron.