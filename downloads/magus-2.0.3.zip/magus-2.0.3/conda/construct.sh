export MAGUS_VERSION=$(python -c "import magus; print(magus.__version__)")
#export CONDA_CONFIG=$(conda config --show --json)
#export LOCAL_CONDABLD_PATH=$(python -c 'import json,os; print(json.loads(os.getenv("CONDA_CONFIG")).get("croot"))')
zip -r examples.zip ../examples
mv examples.zip construct
cp ../LICENSE construct
constructor construct
