Make offline conda install package by [conda-build](https://docs.conda.io/projects/conda-build/en/latest/) and [constructor](https://conda.github.io/constructor/):

```shell
$ ./build.sh
$ ./constructor.sh
```