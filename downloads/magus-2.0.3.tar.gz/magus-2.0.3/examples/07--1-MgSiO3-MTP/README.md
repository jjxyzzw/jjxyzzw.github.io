You must have mlip to run this example:  
https://mlip.skoltech.ru/download/  
  
Use mtp to search MgSiO3 under high pressure.